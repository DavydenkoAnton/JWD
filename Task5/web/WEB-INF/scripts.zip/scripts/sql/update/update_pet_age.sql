UPDATE petbook.pet
SET age = 2
WHERE id = 1;