INSERT INTO  petbook.user (name,email,password,login,phoneNumber,age)
VALUES ('name_', 'email_', 'pass_','pass_',7235647,20);