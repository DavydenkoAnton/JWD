UPDATE petbook.pet
SET name = 'Alfred Schmidt'
WHERE id = 1;