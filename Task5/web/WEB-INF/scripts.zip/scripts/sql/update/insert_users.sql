INSERT INTO  petbook.user (name,email,password,login,phoneNumber,age)
VALUES ('bob', 'email_1', 'password_1','login_1',7235647,20);
INSERT INTO  petbook.user (name,email,password,login,phoneNumber,age)
VALUES ('jack', 'email_2', 'password_2','login_2',7335547,50);
INSERT INTO  petbook.user (name,email,password,login,phoneNumber,age)
VALUES ('ann', 'email_3', 'password_3','login_3',234476,30);
INSERT INTO  petbook.user (name,email,password,login,phoneNumber,age)
VALUES ('bred', 'email_4', 'password_4','login_4',4734135,10);
INSERT INTO  petbook.user (name,email,password,login,phoneNumber,age)
VALUES ('joe', 'email_5', 'password_5','login_5',256256,23);
INSERT INTO  petbook.user (name,email,password,login,phoneNumber,age)
VALUES ('john', 'email_6', 'password_6','login_6',34534,44);
INSERT INTO  petbook.user (name,email,password,login,phoneNumber,age)
VALUES ('nick', 'email_7', 'password_7','login_7',5641534,13);
INSERT INTO  petbook.user (name,email,password,login,phoneNumber,age)
VALUES ('fred', 'email_8', 'password_8','login_8',2623463,34);

