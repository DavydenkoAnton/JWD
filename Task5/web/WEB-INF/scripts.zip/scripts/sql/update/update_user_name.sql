UPDATE petbook.user
SET name = 'Alfred Schmidt'
WHERE id = 1;