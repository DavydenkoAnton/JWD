INSERT INTO petbook.messages (userId,fromUserId,message)
VALUES (1,2,'hello');
