SELECT message 
FROM petbook.messages
WHERE userId=1;