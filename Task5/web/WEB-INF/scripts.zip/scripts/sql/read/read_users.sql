SELECT name 
FROM petbook.user
ORDER BY id ;