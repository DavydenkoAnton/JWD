CREATE TABLE petbook.admin (
    adminName varchar(255) NOT NULL,
    adminPass varchar(255) NOT NULL
);