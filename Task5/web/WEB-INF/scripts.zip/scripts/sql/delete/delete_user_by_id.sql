DELETE FROM petbook.user
WHERE id=1;